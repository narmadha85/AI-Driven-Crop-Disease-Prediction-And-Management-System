package com.crop.cropdisease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropdiseaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
